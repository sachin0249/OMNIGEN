import { GoogleGenAI, Type, LiveServerMessage, Modality } from "@google/genai";
import { OMNIGEN_SYSTEM_PROMPT } from "../constants";
import { Attachment, ChatMessage } from "../types";

// Helper to get a fresh instance with the latest key
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

// Helper to retry operations with exponential backoff
const retryOperation = async <T>(operation: () => Promise<T>, retries = 5, delay = 2000): Promise<T> => {
  try {
    return await operation();
  } catch (error: any) {
    console.warn(`Attempt failed. Retries left: ${retries}. Error:`, error);
    if (retries <= 0) throw error;
    await new Promise(resolve => setTimeout(resolve, delay));
    return retryOperation(operation, retries - 1, delay * 2);
  }
};

const selectModel = (taskType: 'chat' | 'vision' | 'code', complexity: 'low' | 'high' = 'low', useDeepResearch: boolean = false) => {
  if (useDeepResearch) return 'gemini-3-pro-preview';
  if (taskType === 'vision') {
    return complexity === 'high' ? 'gemini-3-pro-preview' : 'gemini-2.5-flash';
  }
  return 'gemini-2.5-flash'; 
};

export const sendGeneralChat = async (
  history: ChatMessage[], 
  currentMessage: string, 
  attachments: Attachment[],
  useDeepResearch: boolean
) => {
  return retryOperation(async () => {
    const ai = getAI();
    const apiHistory = history.map(msg => {
      const parts: any[] = [];
      if (msg.text) parts.push({ text: msg.text });
      if (msg.attachments) {
        msg.attachments.forEach(att => {
          parts.push({ inlineData: { mimeType: att.mimeType, data: att.data } });
        });
      }
      if (parts.length === 0) parts.push({ text: ' ' });
      return { role: msg.role, parts: parts };
    });

    const modelName = selectModel('chat', 'low', useDeepResearch);
    const tools = useDeepResearch ? [{ googleSearch: {} }] : [{ codeExecution: {} }];

    const chat = ai.chats.create({
      model: modelName,
      history: apiHistory,
      config: {
        systemInstruction: OMNIGEN_SYSTEM_PROMPT,
        tools: tools,
      },
    });

    const currentParts: any[] = [];
    if (currentMessage.trim()) currentParts.push({ text: currentMessage });
    if (attachments.length > 0) {
      attachments.forEach(att => {
        currentParts.push({ inlineData: { mimeType: att.mimeType, data: att.data } });
      });
    }
    if (currentParts.length === 0) currentParts.push({ text: "Please continue." });

    const response = await chat.sendMessage({ message: currentParts });

    let text = response.text || '';
    let chartData = null;
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

    const jsonMatch = text.match(/```json\s*({[\s\S]*?"chart":[\s\S]*?})\s*```/);
    if (jsonMatch) {
      try {
        const parsed = JSON.parse(jsonMatch[1]);
        if (parsed.chart) {
          chartData = parsed.chart;
          text = text.replace(jsonMatch[0], '');
        }
      } catch (e) {
        console.error("Failed to parse chart JSON", e);
      }
    }

    return { text, chartData, sources };
  });
};

export const generateChatImage = async (prompt: string) => {
  return retryOperation(async () => {
    const ai = getAI();
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts: [{ text: `Generate an image: ${prompt}` }] }
        });
        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) {
                return `data:image/png;base64,${part.inlineData.data}`;
            }
        }
    } catch (e) {
        console.error("Image generation failed", e);
    }
    return null; 
  });
};

export const fetchSearchContent = async (query: string, context: string) => {
  return retryOperation(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: query,
      config: {
        tools: [{ googleSearch: {} }],
        systemInstruction: `You are a news bot. Context: ${context}. Output: exactly 3 bullet points. One per line. Strict format.`
      },
    });
    return {
      text: response.text || '',
      chunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks
    };
  });
};

export const getMoodMap = async (query: string, location?: {latitude: number, longitude: number}) => {
  return retryOperation(async () => {
    const ai = getAI();
    const config: any = {
      tools: [{ googleMaps: {} }, { googleSearch: {} }],
      // UPDATED PROMPT: Removed HTML tags, using strict Markdown formatting with newlines
      systemInstruction: `You are MoodMap. List places in a grid-ready format.
      
      For each place, output a single bullet point containing all details separated by newlines.
      DO NOT use HTML tags like <br/>.
      
      Format:
      * **[Place Name]**
      📍 [Short Address]
      📏 [Distance from user]
      💡 [Short vibe note]
      
      No intro. No outro. Just the bullet list.`
    };
    
    if (location) {
      config.toolConfig = {
        retrievalConfig: {
          latLng: location
        }
      };
    }

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: query,
      config: config,
    });
    
    return {
      text: response.text || '',
      chunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks
    };
  });
};

export const analyzeWorkspace = async (base64Image: string, mimeType: string, prompt: string) => {
  return retryOperation(async () => {
    const ai = getAI();
    const isHighComplexity = /detailed|deep|scrutinize|examine closely|ocr|read text/.test(prompt);
    const model = selectModel('vision', isHighComplexity ? 'high' : 'low');

    const augmentedPrompt = `${prompt}
    
    TASK: Analyze this workspace image.
    1. Identify key elements.
    2. Provide 3 SPECIFIC, ACTIONABLE suggestions to improve ergonomics, lighting, or productivity setup.
    3. Format suggestions clearly with headings.`;

    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          { inlineData: { mimeType, data: base64Image } },
          { text: augmentedPrompt }
        ]
      },
      config: {
        systemInstruction: OMNIGEN_SYSTEM_PROMPT
      }
    });
    return response.text || '';
  });
};

export const generateText = async (prompt: string) => {
  return retryOperation(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt
    });
    return response.text || '';
  });
}

export const speakText = async (text: string): Promise<ArrayBuffer | null> => {
  return retryOperation(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: text }] }],
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: {
                    prebuiltVoiceConfig: { voiceName: 'Fenrir' },
                },
            },
        },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
        const binaryString = atob(base64Audio);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        return bytes.buffer;
    }
    return null;
  });
}

export const getLiveClient = () => {
    return getAI().live;
}