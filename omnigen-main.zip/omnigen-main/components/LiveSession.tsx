import React, { useRef, useState, useEffect, useCallback } from 'react';
import { getLiveClient } from '../services/geminiService';
import { Modality, LiveServerMessage } from '@google/genai';
import { FaceLandmarker, FilesetResolver, DrawingUtils } from "@mediapipe/tasks-vision";

// Throttle helper to prevent React state churn
const useThrottledState = <T,>(initialValue: T, intervalMs: number): [T, (val: T) => void] => {
    const [state, setState] = useState<T>(initialValue);
    const lastUpdate = useRef<number>(0);
    
    const setThrottled = useCallback((val: T) => {
        const now = Date.now();
        if (now - lastUpdate.current > intervalMs) {
            setState(val);
            lastUpdate.current = now;
        }
    }, [intervalMs]);

    return [state, setThrottled];
};

export const LiveSession: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [status, setStatus] = useState('Initializing Vision Engine...');
  
  // High-performance throttled UI updates (10fps max for text)
  const [distance, setDistance] = useThrottledState<number>(0, 100); 
  const [posture, setPosture] = useThrottledState<string>('Detecting...', 200);

  // Refs for low-latency direct access
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const landmarkerRef = useRef<FaceLandmarker | null>(null);
  const reqIdRef = useRef<number>(0);
  const audioContextRef = useRef<AudioContext | null>(null);

  // 1. Initialize Vision Model (Run once)
  useEffect(() => {
    let landmarker: FaceLandmarker | null = null;
    
    const setupVision = async () => {
        try {
            const filesetResolver = await FilesetResolver.forVisionTasks(
                "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm"
            );
            landmarker = await FaceLandmarker.createFromOptions(filesetResolver, {
                baseOptions: {
                    modelAssetPath: `https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task`,
                    delegate: "GPU" // Critical for performance
                },
                outputFaceBlendshapes: false, // Disable for speed
                runningMode: "VIDEO",
                numFaces: 1
            });
            landmarkerRef.current = landmarker;
            setIsLoading(false);
            setStatus('Ready');
        } catch (e) {
            console.error(e);
            setStatus('Error: Hardware Incompatible');
        }
    };

    setupVision();

    return () => {
        if (landmarker) landmarker.close();
        cleanup();
    };
  }, []);

  const cleanup = () => {
      if (reqIdRef.current) cancelAnimationFrame(reqIdRef.current);
      if (videoRef.current && videoRef.current.srcObject) {
          const stream = videoRef.current.srcObject as MediaStream;
          stream.getTracks().forEach(t => t.stop());
          videoRef.current.srcObject = null;
      }
      if (audioContextRef.current) audioContextRef.current.close();
      setIsActive(false);
  };

  const startSession = async () => {
      if (isActive) {
          cleanup();
          return;
      }

      if (!landmarkerRef.current) return;

      try {
          // 2. High-Performance Stream (Requesting ideal 720p/30fps)
          const stream = await navigator.mediaDevices.getUserMedia({
              video: { width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30 } },
              audio: true
          });

          if (videoRef.current) {
              videoRef.current.srcObject = stream;
              await videoRef.current.play();
              
              setIsActive(true);
              setStatus('Active');
              
              // Start Render Loop
              startPredictionLoop();
              
              // Start Audio (Optional: Only if user wants voice coaching)
              connectAudio(stream);
          }
      } catch (e: any) {
          alert("Camera Error: " + e.message);
      }
  };

  const connectAudio = async (stream: MediaStream) => {
      // Basic audio loopback for connection simulation (Place holder for Gemini Live)
      // In a "Lightweight" mode, we might skip the full Gemini Live handshake to save bandwidth
      // unless specifically requested. For now, we assume local processing is the priority.
  };

  const startPredictionLoop = () => {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const landmarker = landmarkerRef.current;

      if (!video || !canvas || !landmarker) return;

      const ctx = canvas.getContext('2d', { alpha: true }); // Optimized context
      if (!ctx) return;
      
      const drawingUtils = new DrawingUtils(ctx);

      const loop = () => {
          if (!isActive && video.paused) return; // Stop if paused

          const startTime = performance.now();

          // Resize canvas only if needed (Expensive op)
          if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
              canvas.width = video.videoWidth;
              canvas.height = video.videoHeight;
          }

          // 1. CLEAR Canvas (We do NOT draw video here, video is the background element)
          ctx.clearRect(0, 0, canvas.width, canvas.height);

          // 2. DETECT
          // Pass startTime to keep MediaPipe sync
          const result = landmarker.detectForVideo(video, startTime);

          // 3. LOGIC & DRAW
          if (result.faceLandmarks.length > 0) {
              const landmarks = result.faceLandmarks[0];

              // --- Lightweight Drawing ---
              // Only draw the face oval and eyes (minimalist)
              ctx.lineWidth = 1;
              drawingUtils.drawConnectors(landmarks, FaceLandmarker.FACE_LANDMARKS_FACE_OVAL, { color: '#00e5ff', lineWidth: 2 });
              drawingUtils.drawConnectors(landmarks, FaceLandmarker.FACE_LANDMARKS_RIGHT_EYE, { color: '#00e5ff' });
              drawingUtils.drawConnectors(landmarks, FaceLandmarker.FACE_LANDMARKS_LEFT_EYE, { color: '#00e5ff' });

              // --- Metrics Calculation ---
              
              // Distance: Iris approximation
              // 468 is a point near right iris, 473 near left iris center (approx)
              // Better: Cheek to Cheek (454 to 234)
              const dx = (landmarks[454].x - landmarks[234].x) * canvas.width;
              const dy = (landmarks[454].y - landmarks[234].y) * canvas.height;
              const pixelDist = Math.sqrt(dx*dx + dy*dy);
              
              // F = (P * D) / W.  Approx F=600 for many webcams. Avg Face Width = 14.5cm
              // D = (F * W) / P
              const cm = Math.round((650 * 14.5) / pixelDist);
              setDistance(cm);

              // Posture: Nose (1) relative to center of screen X
              const noseX = landmarks[1].x;
              const isCentered = noseX > 0.4 && noseX < 0.6;
              const isClose = cm < 45;

              if (isClose) {
                  setPosture('TOO CLOSE');
                  // Visual Warning
                  ctx.strokeStyle = 'red';
                  ctx.lineWidth = 5;
                  ctx.strokeRect(20, 20, canvas.width - 40, canvas.height - 40);
              } else if (!isCentered) {
                  setPosture('OFF CENTER');
              } else {
                  setPosture('OPTIMAL');
              }
          } else {
              setPosture('NO FACE');
          }

          reqIdRef.current = requestAnimationFrame(loop);
      };

      loop();
  };

  const isDanger = distance > 0 && distance < 45;

  return (
    <div className="relative w-full h-full bg-black flex flex-col items-center justify-center overflow-hidden">
        
        {/* 1. NATIVE VIDEO ELEMENT (Hardware Accelerated Layer) */}
        <video 
            ref={videoRef}
            className="absolute inset-0 w-full h-full object-cover transform scale-x-[-1]" 
            muted 
            playsInline
        />

        {/* 2. TRANSPARENT OVERLAY CANVAS (Drawing Layer) */}
        <canvas 
            ref={canvasRef}
            className="absolute inset-0 w-full h-full object-cover transform scale-x-[-1] pointer-events-none"
        />

        {/* 3. LIGHTWEIGHT HUD (HTML Layer) */}
        <div className="absolute inset-0 pointer-events-none p-6 flex flex-col justify-between z-10">
            {/* Top Bar */}
            <div className="flex justify-between items-start">
                <div className={`
                    backdrop-blur-md border px-6 py-3 rounded-2xl transition-colors duration-300
                    ${isDanger ? 'bg-red-500/20 border-red-500 text-red-500' : 'bg-black/40 border-cyan-500/30 text-cyan-400'}
                `}>
                    <div className="text-[10px] font-mono tracking-widest uppercase opacity-80">Distance</div>
                    <div className="text-4xl font-mono font-black">
                        {distance > 0 ? `${distance}cm` : '--'}
                    </div>
                </div>

                <div className="backdrop-blur-md bg-black/40 border border-white/10 px-6 py-3 rounded-2xl text-right">
                    <div className="text-[10px] text-slate-400 font-mono tracking-widest uppercase opacity-80">Status</div>
                    <div className={`text-2xl font-bold font-mono ${posture === 'OPTIMAL' ? 'text-green-400' : 'text-yellow-400'}`}>
                        {posture}
                    </div>
                </div>
            </div>

            {/* Bottom Controls (Pointer Events Enabled) */}
            <div className="flex flex-col items-center gap-4 pointer-events-auto pb-8">
                {isActive && (
                    <div className="flex gap-2 items-center text-xs font-mono text-cyan-500/80 bg-black/60 px-3 py-1 rounded-full">
                        <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse"></span>
                        OMNISENSE ONLINE
                    </div>
                )}
                
                <button 
                    onClick={startSession}
                    disabled={isLoading}
                    className={`
                        group relative flex items-center justify-center w-20 h-20 rounded-full border-4 shadow-lg transition-all
                        ${isActive 
                            ? 'bg-red-600 border-red-800 hover:scale-95' 
                            : 'bg-cyan-600 border-cyan-800 hover:scale-105 hover:shadow-cyan-500/50'}
                    `}
                >
                    {isLoading ? (
                        <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                        <span className="text-3xl text-white">
                            {isActive ? '⏹' : '👁️'}
                        </span>
                    )}
                </button>
                <div className="text-xs text-slate-500 font-mono">{status}</div>
            </div>
        </div>

        {/* Scanlines Effect */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_4px,3px_100%] pointer-events-none opacity-20"></div>
    </div>
  );
};