import React from 'react';
import { AppMode } from '../types';
import { STYLES } from '../constants';

interface SidebarProps {
  currentMode: AppMode;
  setMode: (mode: AppMode) => void;
  isOpen: boolean;
  toggleSidebar: () => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentMode, setMode, isOpen, toggleSidebar, isDarkMode, toggleTheme }) => {
  const menuItems = [
    { mode: AppMode.DASHBOARD, label: 'Dashboard', icon: '📊' },
    { mode: AppMode.CHAT, label: 'OmniChat (Thinking)', icon: '🧠' },
    { mode: AppMode.OMNI_SENSE, label: 'Omni-Sense (Live)', icon: '🎙️' },
    { mode: AppMode.FOCUS_VISION, label: 'Workspace Scan', icon: '👁️' },
    { mode: AppMode.MOOD_MAP, label: 'MoodMap GPS', icon: '🗺️' },
    { mode: AppMode.RELAXATION, label: 'Relaxation (Jokes)', icon: '🎧' },
  ];

  return (
    <>
       {/* Mobile Overlay */}
       {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-20 lg:hidden backdrop-blur-sm"
          onClick={toggleSidebar}
          role="button"
          aria-label="Close sidebar"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              toggleSidebar();
            }
          }}
        />
      )}

      <div 
        className={`
          fixed lg:static inset-y-0 left-0 z-30
          w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 shadow-xl lg:shadow-none
          transform transition-transform duration-200 ease-in-out
          ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
          flex flex-col
        `}
        role="navigation"
        aria-label="Main menu"
      >
        <div className="p-6 border-b border-slate-100 dark:border-slate-800">
          <h1 className="text-2xl font-bold text-blue-600">
            OMNIGEN™
          </h1>
          <p className="text-xs text-slate-400 mt-1">Wellbeing Optimizer</p>
        </div>

        <nav className="flex-1 overflow-y-auto p-4 space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.mode}
              onClick={() => {
                setMode(item.mode);
                if (window.innerWidth < 1024) toggleSidebar();
              }}
              className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 font-medium transition-all ${
                currentMode === item.mode
                  ? STYLES.activeNavLink
                  : STYLES.navLink
              }`}
              aria-current={currentMode === item.mode ? 'page' : undefined}
            >
              <span className="text-xl opacity-80" aria-hidden="true">{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>
        
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 space-y-4">
            {/* Dark Mode Toggle */}
            <div className="flex items-center justify-between px-2">
                <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Dark Mode</span>
                <button 
                  onClick={toggleTheme}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-slate-900 ${isDarkMode ? 'bg-blue-600' : 'bg-slate-200'}`}
                >
                  <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${isDarkMode ? 'translate-x-6' : 'translate-x-1'}`} />
                </button>
            </div>

            <div className="text-xs text-slate-400 text-center">
                Powered by Gemini 3 Pro
            </div>
        </div>
      </div>
    </>
  );
};