import React, { useState, useRef, useEffect, useMemo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { sendGeneralChat, generateChatImage } from '../services/geminiService';
import { ChatMessage, Attachment, ChartData } from '../types';
import { STYLES } from '../constants';
import { ResponsiveContainer, AreaChart, Area, BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell } from 'recharts';

interface ChatInterfaceProps {
    isDarkMode: boolean;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ isDarkMode }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'Hello, I am OMNIGEN. I can analyze documents, browse the web, generate images, and execute code. How can I help?', timestamp: new Date() }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [useDeepResearch, setUseDeepResearch] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [interimTranscript, setInterimTranscript] = useState(''); // Real-time voice feedback
  const [fileProcessing, setFileProcessing] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null); // To cleanup stream
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      // Cleanup Speech Recognition
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      // Cleanup Media Stream
      if (mediaStreamRef.current) {
          mediaStreamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  // --- Secure JS Execution (Worker) ---
  const runJavascript = (code: string): Promise<string> => {
    return new Promise((resolve) => {
        const blob = new Blob([`
            self.onmessage = function(e) {
                const logs = [];
                const console = { 
                    log: (...args) => logs.push(args.map(a => String(a)).join(' ')), 
                    error: (...args) => logs.push('Error: ' + args.map(a => String(a)).join(' ')),
                    warn: (...args) => logs.push('Warn: ' + args.map(a => String(a)).join(' '))
                };
                try {
                    // Basic security: restrict access to global scope variables if needed
                    const result = new Function('console', e.data)(console);
                    if (result !== undefined) logs.push(String(result));
                    self.postMessage(logs.join('\\n') || 'Success (No output)');
                } catch(err) {
                    self.postMessage('Runtime Error: ' + err.message);
                }
            }
        `], { type: 'application/javascript' });
        
        const worker = new Worker(URL.createObjectURL(blob));
        const timer = setTimeout(() => {
            worker.terminate();
            resolve("Error: Execution timed out (5s limit).");
        }, 5000);

        worker.onmessage = (e) => {
            clearTimeout(timer);
            resolve(e.data);
            worker.terminate();
        };
        
        worker.onerror = (e) => {
            clearTimeout(timer);
            resolve("Error: Worker failure.");
            worker.terminate();
        };

        worker.postMessage(code);
    });
  };

  const handleRunCode = async (lang: string, code: string) => {
      if (loading) return;

      const normalizedLang = lang.toLowerCase();
      
      if (normalizedLang === 'javascript' || normalizedLang === 'js') {
          // Local Secure Execution
          const userMsg: ChatMessage = { role: 'user', text: `Run this JavaScript:\n\`\`\`javascript\n${code}\n\`\`\``, timestamp: new Date() };
          setMessages(prev => [...prev, userMsg]);
          setLoading(true);

          try {
              const output = await runJavascript(code);
              setMessages(prev => [...prev, {
                  role: 'model',
                  text: `**JavaScript Output:**\n\`\`\`\n${output}\n\`\`\``,
                  timestamp: new Date()
              }]);
          } catch (e: any) {
              setMessages(prev => [...prev, { role: 'model', text: `Execution failed: ${e.message}`, timestamp: new Date() }]);
          } finally {
              setLoading(false);
          }

      } else if (normalizedLang === 'python' || normalizedLang === 'py') {
          // Remote Gemini Execution
          const userMsg: ChatMessage = { role: 'user', text: `Run this Python code:\n\`\`\`python\n${code}\n\`\`\``, timestamp: new Date() };
          setMessages(prev => [...prev, userMsg]);
          setLoading(true);

          try {
              // We explicitly prompt the model to use the tool
              const prompt = `Execute the following Python code using the code execution tool and display the output:\n\`\`\`python\n${code}\n\`\`\``;
              
              const historyForCall = [...messages]; 
              
              const response = await sendGeneralChat(
                  historyForCall,
                  prompt,
                  [],
                  false // Force codeExecution tool (Deep Research off)
              );

              setMessages(prev => [...prev, {
                  role: 'model',
                  text: response.text,
                  chartData: response.chartData,
                  sources: response.sources,
                  timestamp: new Date()
              }]);
          } catch (e: any) {
             setMessages(prev => [...prev, { role: 'model', text: "Error: " + e.message, timestamp: new Date() }]);
          } finally {
              setLoading(false);
          }
      }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setFileProcessing(true);
      setUploadProgress(0);
      const newAttachments: Attachment[] = [];
      const totalFiles = files.length;

      for (let i = 0; i < totalFiles; i++) {
        const file = files[i];
        const reader = new FileReader();
        
        await new Promise((resolve) => {
          reader.onprogress = (ev) => {
             if (ev.lengthComputable) {
                 const percentLoaded = ev.loaded / ev.total;
                 // Calculate cumulative progress
                 const overallProgress = ((i + percentLoaded) / totalFiles) * 100;
                 setUploadProgress(Math.min(99, overallProgress));
             }
          };

          reader.onload = (e) => {
            const result = e.target?.result as string;
            const base64 = result.split(',')[1];
            newAttachments.push({
              mimeType: file.type,
              data: base64,
              name: file.name
            });
            resolve(null);
          };
          reader.readAsDataURL(file);
        });
      }
      setAttachments(prev => [...prev, ...newAttachments]);
      setUploadProgress(100);
      
      setTimeout(() => {
          setFileProcessing(false);
          setUploadProgress(0);
      }, 500);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleVoiceInput = async () => {
    if (isRecording) {
      // STOP RECORDING
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
          mediaRecorderRef.current.stop();
      }
      if (recognitionRef.current) {
        recognitionRef.current.stop();
        recognitionRef.current = null;
      }
      // Stop media tracks
      if (mediaStreamRef.current) {
          mediaStreamRef.current.getTracks().forEach(t => t.stop());
          mediaStreamRef.current = null;
      }
      setIsRecording(false);
      setInterimTranscript(''); // Clear interim
      return;
    }

    try {
      // START RECORDING
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      
      // 1. Audio Recording (Blob)
      const recorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];

      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = async () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
           const result = reader.result as string;
           const base64 = result.split(',')[1];
           setAttachments(prev => [...prev, {
             mimeType: 'audio/webm',
             data: base64,
             name: 'Voice Memo'
           }]);
        };
        reader.readAsDataURL(blob);
        // Stop tracks after blob is created
        stream.getTracks().forEach(t => t.stop());
      };

      // 2. Speech-to-Text Transcription
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
          const recognition = new SpeechRecognition();
          recognition.continuous = true;
          recognition.interimResults = true; // Enable real-time feedback
          recognition.lang = 'en-US';

          recognition.onresult = (event: any) => {
             let finalChunk = '';
             let interimChunk = '';

             for (let i = event.resultIndex; i < event.results.length; ++i) {
                if (event.results[i].isFinal) {
                   finalChunk += event.results[i][0].transcript;
                } else {
                   interimChunk += event.results[i][0].transcript;
                }
             }

             if (finalChunk) {
                 setInput(prev => {
                     // Add space if needed
                     const separator = prev && !prev.endsWith(' ') && finalChunk ? ' ' : '';
                     return prev + separator + finalChunk;
                 });
                 setInterimTranscript(''); // Reset interim once finalized
             } else {
                 setInterimTranscript(interimChunk); // Update interim display
             }
          };

          recognition.onerror = (event: any) => {
              console.warn("Speech recognition error:", event.error);
          };
          
          recognition.start();
          recognitionRef.current = recognition;
      }

      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecording(true);
    } catch (e: any) {
      console.error("Mic error", e);
      if (e.name === 'NotAllowedError' || e.name === 'PermissionDismissedError') {
          alert("Microphone permission was denied or dismissed. Please enable permissions in your browser settings to use voice features.");
      } else {
          alert("Could not access microphone: " + e.message);
      }
    }
  };

  const handleSend = async () => {
    if ((!input.trim() && attachments.length === 0) || loading) return;

    const userMsg: ChatMessage = { 
      role: 'user', 
      text: input, 
      timestamp: new Date(),
      attachments: attachments.length > 0 ? [...attachments] : undefined
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setAttachments([]);
    setLoading(true);

    try {
      if (input.toLowerCase().startsWith('generate image') || input.toLowerCase().startsWith('create an image')) {
         const imageBase64 = await generateChatImage(input);
         setMessages(prev => [...prev, {
            role: 'model',
            text: imageBase64 ? "Here is the generated image:" : "Sorry, I could not generate the image.",
            generatedImage: imageBase64 || undefined,
            timestamp: new Date()
         }]);
      } else {
        const response = await sendGeneralChat(
          messages.filter(m => !m.isThinking),
          userMsg.text,
          userMsg.attachments || [],
          useDeepResearch
        );

        setMessages(prev => [...prev, {
          role: 'model',
          text: response.text,
          timestamp: new Date(),
          chartData: response.chartData,
          sources: response.sources
        }]);
      }
    } catch (e: any) {
      setMessages(prev => [...prev, {
        role: 'model',
        text: "Error: " + e.message,
        timestamp: new Date()
      }]);
    } finally {
      setLoading(false);
    }
  };

  // Custom Markdown Components with Secure Execution
  const MarkdownComponents = useMemo(() => ({
    code({inline, className, children, ...props}: any) {
      const match = /language-(\w+)/.exec(className || '');
      const language = match ? match[1] : '';
      const codeContent = String(children).replace(/\n$/, '');
      const canRun = !loading && (language === 'javascript' || language === 'js' || language === 'python' || language === 'py');

      return !inline && match ? (
        <div className="my-4 rounded-lg overflow-hidden border border-slate-300 dark:border-slate-700 bg-[#1e1e1e] shadow-sm group">
          <div className="flex items-center justify-between px-4 py-2 bg-[#2d2d2d] border-b border-slate-600">
            <span className="text-xs font-mono text-slate-300 lowercase">{language}</span>
            <div className="flex items-center gap-3">
                {canRun && (
                    <button 
                        onClick={() => handleRunCode(language, codeContent)}
                        className="flex items-center gap-1 bg-green-600 hover:bg-green-500 text-white text-[10px] px-2 py-1 rounded transition-colors"
                        title="Run Code"
                    >
                        <span>▶</span> Run
                    </button>
                )}
                <div className="flex gap-1.5 opacity-50">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500"></div>
                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-500"></div>
                    <div className="w-2.5 h-2.5 rounded-full bg-green-500"></div>
                </div>
            </div>
          </div>
          <div className="p-4 overflow-x-auto relative">
            <code className={className + " text-sm font-mono leading-relaxed text-gray-300"} {...props}>
              {children}
            </code>
          </div>
        </div>
      ) : (
        <code className="bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-1.5 py-0.5 rounded text-sm font-mono text-blue-600 dark:text-blue-400" {...props}>
          {children}
        </code>
      );
    },
    table({children}: any) {
      return <div className="overflow-x-auto my-4 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm"><table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700 bg-white dark:bg-slate-800 text-sm">{children}</table></div>
    },
    thead({children}: any) {
        return <thead className="bg-slate-50 dark:bg-slate-700">{children}</thead>
    },
    th({children}: any) {
        return <th className="px-4 py-3 text-left font-semibold text-slate-700 dark:text-slate-200 uppercase tracking-wider text-xs">{children}</th>
    },
    td({children}: any) {
        return <td className="px-4 py-3 whitespace-nowrap text-slate-600 dark:text-slate-300 border-t border-slate-100 dark:border-slate-700">{children}</td>
    },
    p({children}: any) {
        return <p className="mb-3 last:mb-0 leading-relaxed text-slate-700 dark:text-slate-200">{children}</p>
    },
    ul({children}: any) {
        return <ul className="list-disc list-outside ml-5 mb-4 space-y-1 text-slate-700 dark:text-slate-200">{children}</ul>
    },
    ol({children}: any) {
        return <ol className="list-decimal list-outside ml-5 mb-4 space-y-1 text-slate-700 dark:text-slate-200">{children}</ol>
    },
    h1({children}: any) {
        return <h1 className="text-2xl font-bold text-slate-900 dark:text-white mt-6 mb-3 border-b border-slate-200 dark:border-slate-700 pb-2">{children}</h1>
    },
    h2({children}: any) {
        return <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-5 mb-2">{children}</h2>
    },
    h3({children}: any) {
        return <h3 className="text-lg font-semibold text-blue-600 dark:text-blue-400 mt-4 mb-2">{children}</h3>
    },
    blockquote({children}: any) {
        return <blockquote className="border-l-4 border-blue-500 pl-4 py-1 my-4 bg-blue-50 dark:bg-blue-900/20 rounded-r italic text-slate-600 dark:text-slate-300">{children}</blockquote>
    },
    a({href, children}: any) {
        return <a href={href} target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 hover:underline">{children}</a>
    }
  }), [loading, isDarkMode]); 

  const renderChart = (chart: ChartData) => {
    const Colors = ['#3b82f6', '#06b6d4', '#8b5cf6', '#ec4899'];
    return (
      <div className="h-64 w-full bg-white dark:bg-slate-800 rounded-lg p-4 my-4 border border-slate-200 dark:border-slate-700 shadow-sm">
        <h4 className="text-sm font-bold text-slate-700 dark:text-slate-200 mb-2">{chart.title}</h4>
        <ResponsiveContainer width="100%" height="100%">
           {chart.type === 'area' ? (
             <AreaChart data={chart.data}>
                <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? "#334155" : "#e2e8f0"} />
                <XAxis dataKey={chart.xAxisKey} stroke={isDarkMode ? "#94a3b8" : "#64748b"} fontSize={10} />
                <YAxis stroke={isDarkMode ? "#94a3b8" : "#64748b"} fontSize={10} />
                <Tooltip contentStyle={{ backgroundColor: isDarkMode ? '#1e293b' : '#ffffff', borderColor: isDarkMode ? '#334155' : '#e2e8f0', color: isDarkMode ? '#f1f5f9' : '#0f172a' }} />
                {chart.dataKeys.map((key, i) => (
                  <Area key={key} type="monotone" dataKey={key} stroke={Colors[i % Colors.length]} fill={Colors[i % Colors.length]} fillOpacity={0.3} />
                ))}
             </AreaChart>
           ) : chart.type === 'pie' ? (
             <PieChart>
                <Pie data={chart.data} dataKey={chart.dataKeys[0]} nameKey={chart.xAxisKey} cx="50%" cy="50%" outerRadius={60}>
                  {chart.data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={Colors[index % Colors.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: isDarkMode ? '#1e293b' : '#ffffff', borderColor: isDarkMode ? '#334155' : '#e2e8f0', color: isDarkMode ? '#f1f5f9' : '#0f172a' }} />
             </PieChart>
           ) : (
             <BarChart data={chart.data}>
                <CartesianGrid strokeDasharray="3 3" stroke={isDarkMode ? "#334155" : "#e2e8f0"} />
                <XAxis dataKey={chart.xAxisKey} stroke={isDarkMode ? "#94a3b8" : "#64748b"} fontSize={10} />
                <YAxis stroke={isDarkMode ? "#94a3b8" : "#64748b"} fontSize={10} />
                <Tooltip contentStyle={{ backgroundColor: isDarkMode ? '#1e293b' : '#ffffff', borderColor: isDarkMode ? '#334155' : '#e2e8f0', color: isDarkMode ? '#f1f5f9' : '#0f172a' }} />
                {chart.dataKeys.map((key, i) => (
                  <Bar key={key} dataKey={key} fill={Colors[i % Colors.length]} />
                ))}
             </BarChart>
           )}
        </ResponsiveContainer>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full max-w-5xl mx-auto p-2 lg:p-6 text-slate-900 dark:text-slate-100">
      <div className="flex-1 overflow-y-auto space-y-6 pb-4 px-2">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
            <div className={`max-w-[95%] lg:max-w-[85%] rounded-2xl p-4 shadow-sm transition-all ${
              msg.role === 'user' 
                ? 'bg-blue-600 text-white rounded-tr-sm shadow-md' 
                : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-tl-sm border border-slate-200 dark:border-slate-700 shadow-sm'
            }`}>
              {msg.attachments && msg.attachments.length > 0 && (
                 <div className="flex gap-2 mb-3 flex-wrap">
                    {msg.attachments.map((att, i) => (
                      att.mimeType.startsWith('image/') ? (
                          <div key={i} className="group relative rounded-lg overflow-hidden border border-white/20 dark:border-slate-600 max-w-[200px] shadow-sm">
                             <img 
                                src={`data:${att.mimeType};base64,${att.data}`} 
                                alt={att.name}
                                className="w-full h-auto object-cover max-h-[200px]"
                             />
                             <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-[10px] p-1 truncate px-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                {att.name}
                             </div>
                          </div>
                      ) : (
                        <div key={i} className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs border ${msg.role === 'user' ? 'bg-white/20 border-white/30 text-white' : 'bg-slate-100 dark:bg-slate-700 border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200'}`}>
                           <span className="text-base">{att.mimeType.includes('audio') ? '🎤' : '📄'}</span>
                           <span className="truncate max-w-[150px] font-medium">{att.name}</span>
                        </div>
                      )
                    ))}
                 </div>
              )}

              <div className="text-sm lg:text-base font-light">
                {msg.role === 'user' ? (
                    <p className="whitespace-pre-wrap">{msg.text}</p>
                ) : (
                    <ReactMarkdown 
                        remarkPlugins={[remarkGfm]}
                        components={MarkdownComponents}
                    >
                        {msg.text}
                    </ReactMarkdown>
                )}
              </div>

              {msg.chartData && renderChart(msg.chartData)}

              {msg.generatedImage && (
                <div className="mt-3">
                  <img src={msg.generatedImage} alt="Generated" className="rounded-lg shadow-lg max-w-full lg:max-w-md border border-slate-200 dark:border-slate-600" />
                  <a href={msg.generatedImage} download="generated-image.png" className="text-xs text-blue-500 underline mt-1 block">Download Image</a>
                </div>
              )}

              {msg.sources && msg.sources.length > 0 && (
                <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-700">
                  <p className="text-[10px] font-bold uppercase text-slate-400 mb-2">Sources</p>
                  <div className="flex flex-wrap gap-2">
                    {msg.sources.map((source, sIdx) => source.web ? (
                      <a key={sIdx} href={source.web.uri} target="_blank" rel="noreferrer" className="flex items-center gap-1 bg-slate-50 dark:bg-slate-700 hover:bg-slate-100 dark:hover:bg-slate-600 px-2 py-1 rounded text-xs text-blue-600 dark:text-blue-400 transition-colors border border-slate-200 dark:border-slate-600">
                        <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                        {source.web.title}
                      </a>
                    ) : null)}
                  </div>
                </div>
              )}
            </div>
            <span className="text-[10px] text-slate-400 mt-1 px-1">
              {msg.role === 'model' ? 'OMNIGEN' : 'You'} • {msg.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
            </span>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
             <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 rounded-tl-sm flex items-center gap-2 shadow-sm">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce delay-75"></div>
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce delay-150"></div>
                <span className="text-xs text-slate-500 dark:text-slate-400">Processing...</span>
             </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      <div className="mt-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 shadow-lg relative">
        {/* Floating Voice Status Bar */}
        {isRecording && (
             <div className="absolute bottom-full left-0 w-full bg-white/95 dark:bg-slate-800/95 backdrop-blur border-t border-x border-slate-200 dark:border-slate-700 rounded-t-lg p-3 flex items-center justify-between text-xs animate-slideUp mb-[-1px] z-10 shadow-lg">
                 <div className="flex items-center gap-3">
                     <span className="flex h-3 w-3 relative">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                     </span>
                     <span className="text-slate-700 dark:text-slate-300 flex items-center gap-2">
                         Recording Audio... 
                         {interimTranscript && (
                             <span className="text-blue-600 dark:text-blue-400 font-medium italic border-l border-slate-300 dark:border-slate-600 pl-2">
                                "{interimTranscript}"
                             </span>
                         )}
                         {!interimTranscript && <span className="text-slate-400 italic">Listening...</span>}
                     </span>
                 </div>
                 <button 
                    onClick={handleVoiceInput} 
                    className="bg-red-50 dark:bg-red-900/20 hover:bg-red-100 dark:hover:bg-red-900/30 text-red-500 dark:text-red-400 px-3 py-1 rounded-full font-medium transition-colors border border-red-200 dark:border-red-800"
                 >
                    Stop & Attach
                 </button>
             </div>
        )}

        <div className="flex items-center gap-3 mb-2 px-1">
           <button 
             onClick={() => fileInputRef.current?.click()} 
             className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
             title="Upload File / Image"
           >
             📎 <span className="text-xs hidden md:inline ml-1">Attach</span>
           </button>
           <button 
             onClick={handleVoiceInput}
             className={`p-2 rounded-lg transition-colors flex items-center gap-1 ${isRecording ? 'bg-red-50 dark:bg-red-900/20 text-red-500 dark:text-red-400' : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700'}`}
             title="Voice Input"
           >
             🎙️ <span className="text-xs hidden md:inline ml-1">{isRecording ? 'Stop' : 'Voice'}</span>
           </button>

           <div className="h-6 w-px bg-slate-200 dark:bg-slate-700 mx-1"></div>

           <label className="flex items-center gap-2 cursor-pointer group">
              <div className={`w-10 h-5 rounded-full p-0.5 transition-colors ${useDeepResearch ? 'bg-blue-600' : 'bg-slate-300 dark:bg-slate-600'}`}>
                 <div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform ${useDeepResearch ? 'translate-x-5' : 'translate-x-0'}`}></div>
              </div>
              <input type="checkbox" className="hidden" checked={useDeepResearch} onChange={() => setUseDeepResearch(!useDeepResearch)} />
              <span className={`text-xs font-medium transition-colors ${useDeepResearch ? 'text-blue-600 dark:text-blue-400' : 'text-slate-500 dark:text-slate-400 group-hover:text-slate-700 dark:group-hover:text-slate-300'}`}>Deep Research</span>
           </label>
        </div>

        {fileProcessing && (
            <div className="mb-3 px-1 animate-fadeIn">
                <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400 mb-1 font-medium">
                    <span>Processing attachments...</span>
                    <span>{Math.round(uploadProgress)}%</span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-700 rounded-full h-1.5 overflow-hidden">
                    <div 
                        className="bg-blue-600 h-1.5 rounded-full transition-all duration-300 ease-out" 
                        style={{ width: `${uploadProgress}%` }}
                    ></div>
                </div>
            </div>
        )}

        {attachments.length > 0 && (
          <div className="flex gap-2 mb-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-slate-300 dark:scrollbar-thumb-slate-600">
            {attachments.map((att, i) => (
              <div key={i} className="relative group bg-slate-50 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 flex items-center gap-3 min-w-[140px] max-w-[220px] p-2 pr-7 shadow-sm transition-all hover:shadow-md">
                 
                 {/* Image Thumbnail or Icon */}
                 {att.mimeType.startsWith('image/') ? (
                    <div className="h-10 w-10 shrink-0 rounded-md overflow-hidden bg-slate-200 dark:bg-slate-600 border border-slate-300 dark:border-slate-500">
                        <img 
                            src={`data:${att.mimeType};base64,${att.data}`} 
                            alt={att.name} 
                            className="h-full w-full object-cover" 
                        />
                    </div>
                 ) : (
                    <div className="h-10 w-10 shrink-0 rounded-md bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center border border-blue-100 dark:border-blue-800 text-lg">
                        {att.mimeType.includes('audio') ? '🎤' : '📄'}
                    </div>
                 )}

                 <div className="flex flex-col overflow-hidden min-w-0">
                    <span className="text-xs text-slate-700 dark:text-slate-200 truncate font-medium" title={att.name}>{att.name}</span>
                    <span className="text-[9px] text-slate-400 uppercase tracking-wider">{att.mimeType.split('/')[1] || 'FILE'}</span>
                 </div>

                 {/* Delete Button */}
                 <button 
                   onClick={() => setAttachments(attachments.filter((_, idx) => idx !== i))}
                   className="absolute top-1 right-1 bg-slate-200 dark:bg-slate-600 hover:bg-red-500 hover:text-white text-slate-500 rounded-full w-5 h-5 flex items-center justify-center text-[10px] opacity-0 group-hover:opacity-100 transition-all z-10 focus:opacity-100"
                   title="Remove attachment"
                 >
                   ×
                 </button>
              </div>
            ))}
          </div>
        )}

        <div className="flex gap-2">
           <input 
             type="file" 
             multiple 
             ref={fileInputRef} 
             className="hidden" 
             onChange={handleFileSelect}
           />
           <input 
             value={input}
             onChange={(e) => setInput(e.target.value)}
             onKeyDown={(e) => e.key === 'Enter' && handleSend()}
             placeholder={isRecording ? "Listening..." : "Ask anything (Analysis, Code, Search, Images)..."}
             className="bg-transparent text-slate-900 dark:text-white w-full focus:outline-none px-2 text-sm md:text-base placeholder-slate-400 dark:placeholder-slate-500"
             autoFocus
           />
           <button 
             onClick={handleSend} 
             disabled={loading || (!input.trim() && attachments.length === 0)}
             className={STYLES.buttonPrimary + " rounded-lg py-2 px-6"}
           >
             Send
           </button>
        </div>
      </div>
    </div>
  );
};