import React, { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { fetchSearchContent, generateText } from '../services/geminiService';
import { STYLES } from '../constants';
import { GroundingChunk } from '../types';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip } from 'recharts';

interface NewsSection {
  title: string;
  query: string;
  context: string;
  data: string;
  chunks: GroundingChunk[];
  loading: boolean;
}

interface InsightData {
  summary: string;
  metrics: { subject: string; A: number; fullMark: number }[];
}

interface DashboardProps {
  isDarkMode: boolean;
}

export const Dashboard: React.FC<DashboardProps> = ({ isDarkMode }) => {
  // News States
  const [marketNews, setMarketNews] = useState<NewsSection>({
    title: "Market Insights",
    query: "Latest global stock market trends, crypto volatility, and economic indicators today",
    context: "3 short bullets. Max 10 words each.",
    data: "", chunks: [], loading: false
  });

  const [businessNews, setBusinessNews] = useState<NewsSection>({
    title: "Business News",
    query: "Major corporate mergers, tech company announcements, and business headlines today",
    context: "3 short bullets. Max 10 words each.",
    data: "", chunks: [], loading: false
  });

  const [entNews, setEntNews] = useState<NewsSection>({
    title: "Entertainment",
    query: "Latest viral entertainment news, movie releases, and celebrity trending topics today",
    context: "3 short bullets. Max 10 words each.",
    data: "", chunks: [], loading: false
  });

  // AI Insight State
  const [insight, setInsight] = useState<InsightData | null>(null);
  const [insightLoading, setInsightLoading] = useState(false);

  const fetchData = async (
      setter: React.Dispatch<React.SetStateAction<NewsSection>>, 
      current: NewsSection
    ) => {
    setter(prev => ({ ...prev, loading: true }));
    try {
      const res = await fetchSearchContent(current.query, current.context);
      setter(prev => ({ ...prev, data: res.text, chunks: res.chunks || [], loading: false }));
    } catch (e) {
      setter(prev => ({ ...prev, data: "Unable to load data at this moment.", loading: false }));
    }
  };

  const fetchInsights = async () => {
    setInsightLoading(true);
    try {
        const prompt = `
            Analyze the current global macro-environment (Tech, Finance, Culture).
            Return a valid JSON object (strictly NO markdown, NO \`\`\`, just raw JSON) with this schema:
            {
              "summary": "A provocative, 1-sentence strategic executive summary of the world right now.",
              "metrics": [
                {"subject": "Volatility", "A": <0-100 integer>},
                {"subject": "Innovation", "A": <0-100 integer>},
                {"subject": "Risk", "A": <0-100 integer>},
                {"subject": "Growth", "A": <0-100 integer>},
                {"subject": "Sentiment", "A": <0-100 integer>}
              ]
            }
        `;
        const text = await generateText(prompt);
        
        // Robust JSON Extraction
        let cleanText = text.trim();
        // Try to find the first { and last }
        const firstBrace = cleanText.indexOf('{');
        const lastBrace = cleanText.lastIndexOf('}');
        
        if (firstBrace !== -1 && lastBrace !== -1) {
            cleanText = cleanText.substring(firstBrace, lastBrace + 1);
        }

        const data = JSON.parse(cleanText);
        
        // Add fullMark for chart scaling
        const metrics = data.metrics.map((m: any) => ({...m, fullMark: 100}));
        setInsight({ summary: data.summary, metrics });
    } catch (e) {
        console.warn("Insight fallback triggered due to:", e);
        // Fallback data prevents the UI from breaking on error
        setInsight({
            summary: "Global markets are showing mixed signals. (Data Unavailable)",
            metrics: [
                { subject: 'Volatility', A: 50, fullMark: 100 },
                { subject: 'Innovation', A: 50, fullMark: 100 },
                { subject: 'Risk', A: 50, fullMark: 100 },
                { subject: 'Growth', A: 50, fullMark: 100 },
                { subject: 'Sentiment', A: 50, fullMark: 100 },
            ]
        });
    } finally {
        setInsightLoading(false);
    }
  };

  useEffect(() => {
    // PARALLEL LOADING
    // We initiate all requests immediately to maximize speed.
    // The retry logic in the service layer will handle transient 429s.
    
    // 1. Load Hero Insight
    fetchInsights();
    
    // 2. Load News Sections in Parallel
    fetchData(setMarketNews, marketNews);
    fetchData(setBusinessNews, businessNews);
    fetchData(setEntNews, entNews);
  }, []);

  const renderNewsCard = (section: NewsSection, refresh: () => void) => (
    <div className={STYLES.card + " flex flex-col h-full transition-all duration-300 hover:shadow-md"}>
      <div className="flex justify-between items-center mb-4 border-b border-slate-100 dark:border-slate-700 pb-2">
        <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">{section.title}</h3>
        <button onClick={refresh} className="text-xs text-blue-600 hover:text-blue-500 font-medium dark:text-blue-400">Refresh</button>
      </div>
      
      <div className="flex-1 overflow-y-auto min-h-[150px] max-h-[300px] scrollbar-thin scrollbar-thumb-slate-300 dark:scrollbar-thumb-slate-600 scrollbar-track-transparent">
        {section.loading ? (
           <div className="animate-pulse space-y-3">
             <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded w-3/4"></div>
             <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded w-full"></div>
             <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded w-5/6"></div>
           </div>
        ) : (
           <div className="text-sm text-slate-600 dark:text-slate-300">
             <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                    ul: ({node, ...props}) => <ul className="space-y-3" {...props} />,
                    li: ({node, ...props}) => (
                        <li className="flex items-start gap-2 leading-relaxed mb-2">
                            <span className="text-blue-500 mt-1.5 text-[10px] shrink-0">●</span>
                            <span className="flex-1">
                                {props.children}
                            </span>
                        </li>
                    ),
                    p: ({node, ...props}) => <span {...props} />, // Flatten paragraphs inside lists
                    strong: ({node, ...props}) => <strong className="text-slate-900 dark:text-white font-semibold" {...props} />,
                    a: ({node, ...props}) => <a className="text-blue-600 dark:text-blue-400 hover:underline" {...props} />
                }}
             >
                {section.data || "No data available."}
             </ReactMarkdown>
           </div>
        )}
      </div>

      {section.chunks.length > 0 && (
        <div className="mt-4 pt-2 border-t border-slate-100 dark:border-slate-700">
          <h4 className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1">Sources</h4>
          <ul className="space-y-1">
            {section.chunks.slice(0, 3).map((chunk, idx) => (
              chunk.web ? (
                <li key={idx}>
                  <a href={chunk.web.uri} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 dark:text-blue-400 hover:underline truncate block flex items-center gap-1">
                    <span className="w-1 h-1 bg-blue-500 rounded-full"></span>
                    {chunk.web.title}
                  </a>
                </li>
              ) : null
            ))}
          </ul>
        </div>
      )}
    </div>
  );

  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full text-slate-900 dark:text-slate-100">
      <div className="flex justify-between items-end mb-2">
         <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Executive Dashboard</h2>
         <span className="text-xs font-mono text-slate-400">LIVE FEED</span>
      </div>
      
      {/* 1. Hero: Strategic Radar (The "Eye-Catching" Element) */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-black text-white rounded-2xl p-6 shadow-2xl border border-slate-700 relative overflow-hidden">
         {/* Background Effect */}
         <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/20 rounded-full blur-[80px] -mr-16 -mt-16 pointer-events-none"></div>
         <div className="absolute bottom-0 left-0 w-48 h-48 bg-purple-500/20 rounded-full blur-[60px] -ml-10 -mb-10 pointer-events-none"></div>

         <div className="flex flex-col md:flex-row gap-8 relative z-10">
            {/* Left: Summary & Text */}
            <div className="flex-1 flex flex-col justify-center space-y-4">
                <div>
                   <h3 className="text-blue-400 font-mono text-xs uppercase tracking-widest mb-2">Omni-Vision™ Synthesis</h3>
                   <h4 className="text-2xl md:text-3xl font-bold leading-tight">
                       {insightLoading ? (
                           <span className="animate-pulse bg-white/20 text-transparent rounded">Loading Global Context...</span>
                       ) : (
                           insight?.summary || "Analyzing global vectors..."
                       )}
                   </h4>
                </div>
                
                <p className="text-slate-400 text-sm max-w-lg">
                    Real-time cross-vector analysis of market volatility, technological acceleration, and consumer sentiment computed by Gemini 3 Pro.
                </p>

                <div className="flex gap-4 pt-2">
                    <div className="px-3 py-1 bg-white/5 rounded border border-white/10 text-xs text-slate-300">
                        <span className="text-green-400 font-bold">●</span> Live Data
                    </div>
                    <div className="px-3 py-1 bg-white/5 rounded border border-white/10 text-xs text-slate-300">
                        <span className="text-purple-400 font-bold">AI</span> Predictive
                    </div>
                </div>
            </div>

            {/* Right: The Radar Chart */}
            <div className="w-full md:w-1/3 h-[250px] flex items-center justify-center">
                 {insightLoading ? (
                     <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                 ) : (
                     <ResponsiveContainer width="100%" height="100%">
                         <RadarChart cx="50%" cy="50%" outerRadius="70%" data={insight?.metrics || []}>
                            <PolarGrid stroke="#475569" strokeOpacity={0.5} />
                            <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                            <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                            <Radar
                                name="Global Pulse"
                                dataKey="A"
                                stroke="#3b82f6"
                                strokeWidth={2}
                                fill="#3b82f6"
                                fillOpacity={0.5}
                            />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f1f5f9', borderRadius: '8px', fontSize: '12px' }}
                                itemStyle={{ color: '#3b82f6' }}
                            />
                         </RadarChart>
                     </ResponsiveContainer>
                 )}
            </div>
         </div>
      </div>

      {/* 2. News Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {renderNewsCard(marketNews, () => fetchData(setMarketNews, marketNews))}
        {renderNewsCard(businessNews, () => fetchData(setBusinessNews, businessNews))}
        {renderNewsCard(entNews, () => fetchData(setEntNews, entNews))}
      </div>
    </div>
  );
};
