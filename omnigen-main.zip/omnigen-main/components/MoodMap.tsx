import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { getMoodMap } from '../services/geminiService';
import { STYLES } from '../constants';
import { GroundingChunk } from '../types';

export const MoodMap: React.FC = () => {
    const [query, setQuery] = useState('');
    const [response, setResponse] = useState('');
    const [chunks, setChunks] = useState<GroundingChunk[]>([]);
    const [loading, setLoading] = useState(false);
    const [userLocation, setUserLocation] = useState<string>('Ready to Locate');

    const handleSearch = async () => {
        if (!query.trim()) return;
        setLoading(true);
        setChunks([]);
        setResponse('');
        setUserLocation('Acquiring GPS...');
        
        try {
            let loc = { latitude: 37.7749, longitude: -122.4194 }; // Default SF
            
            // Artificial delay for "Locating" feel if using default, or real wait
            if (navigator.geolocation) {
                 await new Promise<void>((resolve) => {
                     navigator.geolocation.getCurrentPosition((pos) => {
                         loc = { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
                         setUserLocation(`${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`);
                         resolve();
                     }, (err) => {
                         console.warn(err);
                         setUserLocation('San Francisco (Default)');
                         resolve();
                     }, { timeout: 5000 });
                 });
            } else {
                setUserLocation('San Francisco (Default)');
            }

            const res = await getMoodMap(query, loc);
            setResponse(res.text);
            if (res.chunks) setChunks(res.chunks);

        } catch (e: any) {
            setResponse("Error: " + e.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="relative min-h-full pb-20 bg-slate-50 dark:bg-slate-900 overflow-hidden">
             {/* Background Decoration */}
             <div className="absolute top-0 left-0 w-full h-96 bg-gradient-to-b from-blue-500/10 to-transparent pointer-events-none"></div>
             <div className="absolute -top-20 -right-20 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl pointer-events-none"></div>

             <div className="max-w-4xl mx-auto p-6 relative z-10 space-y-8">
                
                {/* Header */}
                <div className="text-center space-y-4 pt-8">
                    <div className="inline-flex items-center justify-center p-4 bg-blue-100 dark:bg-blue-900/30 rounded-full mb-2 shadow-sm">
                        <span className="text-4xl">🗺️</span>
                    </div>
                    <h2 className="text-4xl md:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                        MoodMap GPS™
                    </h2>
                    <p className="text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
                        Discover the perfect "third place" based on your current vibe. 
                        <br className="hidden md:block" />
                        From quiet reading nooks to bustling creative hubs.
                    </p>
                </div>

                {/* Search Box */}
                <div className="max-w-2xl mx-auto">
                    <div className="relative group">
                        <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-200"></div>
                        <div className="relative bg-white dark:bg-slate-800 rounded-2xl p-2 shadow-xl flex items-center gap-2 border border-slate-200 dark:border-slate-700">
                             <span className="pl-4 text-2xl animate-pulse">📍</span>
                             <input 
                                value={query} 
                                onChange={(e) => setQuery(e.target.value)} 
                                placeholder="Where do you want to be mentally? (e.g. 'cozy rainy day cafe')"
                                className="flex-1 bg-transparent border-none focus:ring-0 text-lg p-2 text-slate-900 dark:text-white placeholder-slate-400"
                                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                                autoFocus
                            />
                            <button 
                                onClick={handleSearch} 
                                disabled={loading} 
                                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-bold transition-all transform active:scale-95 disabled:opacity-70 disabled:cursor-not-allowed shadow-md"
                            >
                                {loading ? 'Scouting...' : 'Go'}
                            </button>
                        </div>
                    </div>
                    
                    {/* Location Badge */}
                    <div className="flex justify-center mt-3">
                         <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-200/50 dark:bg-slate-800/50 text-[10px] uppercase font-mono tracking-widest text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700">
                             <span className={`w-1.5 h-1.5 rounded-full ${loading ? 'bg-yellow-500 animate-ping' : 'bg-green-500'}`}></span>
                             {userLocation}
                         </div>
                    </div>
                </div>

                {/* Results Section */}
                {(response || loading) && (
                    <div className="animate-slideUp min-h-[200px]">
                        {loading ? (
                             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
                                 {[1, 2, 3, 4].map(i => (
                                     <div key={i} className="h-40 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-5 animate-pulse flex flex-col justify-between">
                                         <div className="h-6 bg-slate-200 dark:bg-slate-700 rounded w-2/3"></div>
                                         <div className="space-y-3">
                                             <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded w-full"></div>
                                             <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded w-3/4"></div>
                                         </div>
                                     </div>
                                 ))}
                             </div>
                        ) : (
                            <div className="space-y-8">
                                <div className="grid grid-cols-1 gap-4">
                                     {/* We style the markdown list items as cards with pre-wrap for newlines */}
                                     <ReactMarkdown
                                        remarkPlugins={[remarkGfm]}
                                        components={{
                                            ul: ({node, ...props}) => <ul className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-5" {...props} />,
                                            li: ({node, ...props}) => (
                                                <li className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col gap-2 relative overflow-hidden group whitespace-pre-wrap">
                                                    <div className="absolute top-0 left-0 w-1.5 h-full bg-gradient-to-b from-blue-500 to-cyan-400 opacity-80"></div>
                                                    <div className="pl-2 flex flex-col h-full text-slate-700 dark:text-slate-200">
                                                        {props.children}
                                                    </div>
                                                </li>
                                            ),
                                            p: ({node, ...props}) => <span className="block" {...props} />, // Ensure paragraphs don't add extra margin inside lists
                                            strong: ({node, ...props}) => <strong className="text-xl font-bold text-slate-900 dark:text-white block mb-1 tracking-tight" {...props} />,
                                        }}
                                    >
                                        {response}
                                    </ReactMarkdown>
                                </div>

                                {chunks.length > 0 && (
                                    <div className="bg-white/50 dark:bg-slate-800/50 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 backdrop-blur-sm">
                                        <h4 className="flex items-center gap-2 text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-4">
                                            <span>🗺️</span> Verified Locations
                                        </h4>
                                        <div className="flex flex-wrap gap-3">
                                            {chunks.map((chunk, i) => chunk.maps && (
                                                <a 
                                                    key={i} 
                                                    href={chunk.maps.uri} 
                                                    target="_blank" 
                                                    rel="noreferrer" 
                                                    className="group flex items-center gap-3 pl-2 pr-4 py-2 bg-white dark:bg-slate-800 rounded-lg hover:bg-blue-50 dark:hover:bg-slate-700 transition border border-slate-200 dark:border-slate-600 shadow-sm text-sm text-slate-700 dark:text-slate-200"
                                                >
                                                    <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center text-blue-600 dark:text-blue-400 group-hover:scale-110 transition-transform">
                                                        📍
                                                    </div>
                                                    <div className="flex flex-col">
                                                        <span className="font-semibold">{chunk.maps.title}</span>
                                                        <span className="text-[10px] text-slate-400">Open in Maps</span>
                                                    </div>
                                                </a>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                )}
             </div>
        </div>
    );
};