import React, { useState, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { STYLES } from '../constants';
import { analyzeWorkspace } from '../services/geminiService';

export const ImageTools: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('');
  const [prompt, setPrompt] = useState('');
  const [output, setOutput] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setMimeType(file.type);
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        const base64Data = base64String.split(',')[1];
        setImage(base64Data);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAction = async () => {
    setLoading(true);
    setOutput('');
    
    try {
      if (image) {
        // Updated call to service which includes the suggestion logic
        const res = await analyzeWorkspace(image, mimeType, prompt || "Analyze this workspace and provide specific setup improvements.");
        setOutput(res || '');
      }
    } catch (e: any) {
      setOutput("Error: " + e.message);
    } finally {
      setLoading(false);
    }
  };

  const previewSrc = image ? `data:${mimeType};base64,${image}` : null;

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6 pb-20 text-slate-900 dark:text-slate-100">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white">
          FocusVision Pro™
        </h2>
        <p className="text-slate-500 dark:text-slate-400 mt-2">
            Upload a workspace photo. Get AI analysis & ergonomic suggestions.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Input */}
        <div className={STYLES.card + " space-y-4 h-fit"}>
          <div className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg p-6 text-center hover:border-blue-500 transition-colors cursor-pointer bg-slate-50 dark:bg-slate-900" onClick={() => fileInputRef.current?.click()}>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              className="hidden" 
              accept="image/*"
            />
            <p className="text-slate-500 dark:text-slate-400">
              {image ? "Click to change image" : "Click to upload workspace photo"}
            </p>
          </div>

          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="E.g., How can I improve lighting? Is my monitor height correct?"
            className={STYLES.input + " h-32"}
          />

          <button 
            onClick={handleAction} 
            disabled={loading || !image} 
            className={STYLES.buttonPrimary + " w-full"}
          >
            {loading ? "Scanning & Thinking..." : "Analyze Workspace"}
          </button>
        </div>

        {/* Output */}
        <div className={STYLES.card + " flex flex-col min-h-[400px]"}>
          {loading ? (
             <div className="flex-1 flex flex-col items-center justify-center space-y-4">
                <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                <p className="text-slate-500 dark:text-slate-400 animate-pulse">Generating suggestions...</p>
             </div>
          ) : (
             <>
                {previewSrc && (
                    <div className="w-full h-48 mb-4 bg-slate-100 dark:bg-slate-900 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700">
                         <img src={previewSrc} alt="Workspace" className="w-full h-full object-contain" />
                    </div>
                )}
                {output ? (
                    <div className="flex-1 overflow-y-auto pr-2">
                         <h3 className="text-sm font-bold uppercase text-slate-400 mb-3">AI Recommendations</h3>
                         <div className="prose dark:prose-invert text-sm max-w-none">
                             <ReactMarkdown 
                                remarkPlugins={[remarkGfm]}
                                components={{
                                    h1: ({node, ...props}) => <h3 className="text-lg font-bold text-blue-600 dark:text-blue-400 mt-4 first:mt-0" {...props} />,
                                    h2: ({node, ...props}) => <h4 className="text-base font-bold text-slate-800 dark:text-slate-200 mt-3" {...props} />,
                                    h3: ({node, ...props}) => <h5 className="text-sm font-bold text-slate-700 dark:text-slate-300 mt-2" {...props} />,
                                    strong: ({node, ...props}) => <strong className="text-blue-600 dark:text-blue-400 font-semibold" {...props} />,
                                    ul: ({node, ...props}) => <ul className="list-disc ml-4 space-y-1 my-2" {...props} />,
                                }}
                             >
                                {output}
                             </ReactMarkdown>
                         </div>
                    </div>
                ) : (
                    <div className="flex-1 flex items-center justify-center text-slate-400 dark:text-slate-500 text-center p-8">
                        Upload an image to receive personalized workspace improvements.
                    </div>
                )}
             </>
          )}
        </div>
      </div>
    </div>
  );
};