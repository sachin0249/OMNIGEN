import React, { useState, useRef, useEffect } from 'react';
import { generateText, speakText } from '../services/geminiService';
import { STYLES } from '../constants';

export const Relaxation: React.FC = () => {
    const [topic, setTopic] = useState('office life');
    const [words, setWords] = useState<string[]>([]);
    const [currentWordIndex, setCurrentWordIndex] = useState<number>(-1);
    const [loading, setLoading] = useState(false);
    const [isPlaying, setIsPlaying] = useState(false);
    
    const audioContextRef = useRef<AudioContext | null>(null);
    const animationFrameRef = useRef<number | null>(null);

    // Cleanup on unmount
    useEffect(() => {
        return () => {
            if (audioContextRef.current) {
                audioContextRef.current.close();
            }
            if (animationFrameRef.current) {
                cancelAnimationFrame(animationFrameRef.current);
            }
        };
    }, []);

    const handleTellJoke = async () => {
        if (loading || isPlaying) return;
        setLoading(true);
        setWords([]);
        setCurrentWordIndex(-1);

        try {
            // 1. Generate Joke Text
            // Explicitly ask to not include quotes so the word count matches better
            const text = await generateText(`Write a very short, funny, clean joke about ${topic}. Max 20 words. Do not include quotes.`);
            const wordList = text.trim().split(/\s+/);
            setWords(wordList);

            // 2. Generate Audio
            const audioBuffer = await speakText(text);
            
            if (audioBuffer) {
                await playAudio(audioBuffer, wordList.length);
            }

        } catch (e: any) {
            alert("Failed to tell joke: " + e.message);
        } finally {
            setLoading(false);
        }
    };

    const playAudio = async (buffer: ArrayBuffer, totalWords: number) => {
        try {
            if (!audioContextRef.current) {
                audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 24000});
            }
            const ctx = audioContextRef.current;

            // Resume context if browser suspended it (autoplay policy)
            if (ctx.state === 'suspended') {
                await ctx.resume();
            }
            
            // Raw PCM data (Int16) - Gemini TTS standard
            const dataInt16 = new Int16Array(buffer);
            const audioBuffer = ctx.createBuffer(1, dataInt16.length, 24000);
            const channelData = audioBuffer.getChannelData(0);
            
            for (let i = 0; i < dataInt16.length; i++) {
                channelData[i] = dataInt16[i] / 32768.0;
            }
            
            const source = ctx.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(ctx.destination);
            
            setIsPlaying(true);
            source.start(0);

            // Karaoke Animation Logic
            const startTime = ctx.currentTime;
            const duration = audioBuffer.duration;
            
            const animate = () => {
                const elapsed = ctx.currentTime - startTime;
                
                if (elapsed >= duration) {
                    setCurrentWordIndex(totalWords);
                    return;
                }

                // Linear interpolation for word index:
                // We assume words are spoken at a roughly constant rate.
                // (elapsed / duration) gives us percentage complete (0.0 to 1.0)
                const progress = elapsed / duration;
                const index = Math.floor(progress * totalWords);
                setCurrentWordIndex(index);

                animationFrameRef.current = requestAnimationFrame(animate);
            };

            animationFrameRef.current = requestAnimationFrame(animate);

            source.onended = () => {
                setIsPlaying(false);
                setCurrentWordIndex(totalWords); // Ensure all words are marked as read
                if (animationFrameRef.current) {
                    cancelAnimationFrame(animationFrameRef.current);
                }
            };
        } catch (e) {
            console.error(e);
            setIsPlaying(false);
        }
    };

    return (
        <div className="p-6 max-w-2xl mx-auto space-y-8 flex flex-col items-center justify-center min-h-[500px] text-slate-900 dark:text-slate-100">
            <div className="text-center">
                <h2 className="text-4xl font-bold text-slate-900 dark:text-white mb-4">Comedy Break</h2>
                <p className="text-slate-500 dark:text-slate-400">Lighten the mood with AI-generated audio jokes.</p>
            </div>

            <div className={STYLES.card + " w-full p-8 text-center space-y-6 flex flex-col items-center"}>
                {/* Status Icon */}
                <div className={`text-6xl mb-4 transition-transform duration-500 ${isPlaying ? 'scale-110 animate-bounce' : ''}`}>
                    {isPlaying ? '🗣️' : (loading ? '🤔' : '😂')}
                </div>

                {/* Input Area */}
                <div className="space-y-2 w-full max-w-md">
                    <label className="text-sm text-slate-500 dark:text-slate-400">Joke Topic</label>
                    <div className="flex gap-2 justify-center">
                        <input 
                            value={topic}
                            onChange={(e) => setTopic(e.target.value)}
                            placeholder="e.g., coding, coffee, meetings"
                            className={STYLES.input + " text-center"}
                            onKeyDown={(e) => e.key === 'Enter' && handleTellJoke()}
                        />
                    </div>
                </div>

                <button 
                    onClick={handleTellJoke} 
                    disabled={loading || isPlaying}
                    className={STYLES.buttonPrimary + " w-full max-w-md py-3 text-lg transition-all active:scale-95"}
                >
                    {loading ? "Thinking..." : isPlaying ? "Listening..." : "Tell me a joke"}
                </button>

                {/* Karaoke Text Display */}
                {words.length > 0 && (
                    <div className="mt-8 p-8 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-700 w-full min-h-[120px] flex items-center justify-center shadow-inner">
                        <div className="flex flex-wrap justify-center gap-x-2 gap-y-2 text-2xl leading-relaxed max-w-lg">
                            {words.map((word, i) => (
                                <span 
                                    key={i}
                                    className={`
                                        transition-all duration-200 rounded px-1
                                        ${i === currentWordIndex 
                                            ? 'text-blue-600 dark:text-blue-400 font-extrabold scale-125 bg-blue-50 dark:bg-blue-900/30 shadow-sm transform -translate-y-1' 
                                            : i < currentWordIndex 
                                                ? 'text-slate-800 dark:text-slate-200 opacity-100' 
                                                : 'text-slate-300 dark:text-slate-600 blur-[0.5px]'}
                                    `}
                                >
                                    {word}
                                </span>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};