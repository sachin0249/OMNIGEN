import React, { useState } from 'react';
import { generateChatImage } from '../services/geminiService';
import { STYLES } from '../constants';

export const MarketingGenerator: React.FC = () => {
    const defaultPrompt = "A futuristic, cinematic shot of a high-tech web dashboard named 'OMNIGEN'. Dark mode UI, glowing cyan and blue data visualizations, radar charts, live video feed with biometric analysis overlay. 8k resolution, photorealistic, depth of field, cyberpunk corporate aesthetic, highly detailed interface design.";
    const [prompt, setPrompt] = useState(defaultPrompt);
    const [image, setImage] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);

    const handleGenerate = async () => {
        if (loading) return;
        setLoading(true);
        setImage(null);
        try {
            const result = await generateChatImage(prompt);
            if (result) {
                setImage(result);
            } else {
                alert("Image generation failed. Please try again.");
            }
        } catch (e: any) {
            alert("Error: " + e.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="p-6 max-w-4xl mx-auto space-y-8 text-slate-900 dark:text-slate-100 pb-20">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Omni-Brand Generator</h2>
                <p className="text-slate-500 dark:text-slate-400">Generate professional marketing assets and thumbnails for OMNIGEN™.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Controls */}
                <div className={STYLES.card + " space-y-4"}>
                    <div>
                        <label className="text-xs font-bold uppercase text-slate-400 mb-1 block">Creative Prompt</label>
                        <textarea 
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            className={STYLES.input + " h-40 text-sm"}
                        />
                    </div>
                    <div className="flex gap-2">
                        <button 
                            onClick={() => setPrompt(defaultPrompt)}
                            className={STYLES.buttonSecondary + " flex-1 text-xs"}
                        >
                            Reset to Default
                        </button>
                        <button 
                            onClick={handleGenerate}
                            disabled={loading}
                            className={STYLES.buttonPrimary + " flex-1"}
                        >
                            {loading ? "Rendering..." : "Generate 4K Thumbnail"}
                        </button>
                    </div>
                    <p className="text-xs text-slate-400 italic">
                        Powered by Gemini 2.5 Flash Image. Best results with detailed descriptions of UI elements and lighting.
                    </p>
                </div>

                {/* Preview */}
                <div className={STYLES.card + " flex flex-col items-center justify-center min-h-[350px] bg-slate-100 dark:bg-black/20"}>
                    {loading ? (
                        <div className="flex flex-col items-center gap-3">
                             <div className="relative w-16 h-16">
                                <div className="absolute inset-0 border-4 border-slate-200 dark:border-slate-700 rounded-full"></div>
                                <div className="absolute inset-0 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                             </div>
                             <span className="text-sm font-mono text-blue-500 animate-pulse">Dreaming pixels...</span>
                        </div>
                    ) : image ? (
                        <div className="w-full space-y-3 animate-fadeIn">
                            <img 
                                src={image} 
                                alt="Generated Asset" 
                                className="w-full h-auto rounded-lg shadow-2xl border border-slate-200 dark:border-slate-700"
                            />
                            <a 
                                href={image} 
                                download="omnigen-thumbnail.png" 
                                className="block w-full text-center bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg font-medium transition-colors"
                            >
                                ⬇️ Download Asset
                            </a>
                        </div>
                    ) : (
                        <div className="text-center text-slate-400">
                            <div className="text-4xl mb-2">🖼️</div>
                            <p>No image generated yet.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};